package com.hemanth.learning.jpa.jpa_in_10_steps.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.hemanth.learning.jpa.jpa_in_10_steps.enity.User;
@Repository
@Transactional
public class UserDaoService {
	@PersistenceContext
	private EntityManager entitymanager ; 
	
	public long insert(User user){ 
		
		entitymanager.persist(user);
		return user.getId() ; 
	}

}
