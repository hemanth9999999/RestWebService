package com.hemanth.learning.jpa.jpa_in_10_steps.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hemanth.learning.jpa.jpa_in_10_steps.enity.User;

public interface UserRepository extends JpaRepository<User, Long> {

}
