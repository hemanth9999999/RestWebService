package com.hemanth.rest.webservices.restfulwebsevices.helloWorld;

import static  org.springframework.hateoas.mvc.ControllerLinkBuilder.*;
import java.net.URI;
import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.hemanth.rest.webservices.restfulwebsevices.helloWorld.exceptions.UserNotFoundException;

@RestController
public class UserResource {
	private static final Logger LOGGER = LogManager.getLogger(UserResource.class) ; 
	@Autowired
	private UserDaoService service ;
	
	@GetMapping("/users")
	public List<User>RetriveUsers()
	{ 
		LOGGER.info("inside resource retrive users controller ");  
		return service.findAll() ; 
	}
	
	@GetMapping("/users/{Id}")
	public org.springframework.hateoas.Resource<User> GetUser(@PathVariable String Id)
	{ 
		User user = service.findUser(Id) ; 
		if ( user == null)
		{ 
			throw new UserNotFoundException("ID not found : "+ Id) ; 
		}
		LOGGER.info("inside GetUser Controller");  
		org.springframework.hateoas.Resource<User> resource = new org.springframework.hateoas.Resource<User>( user); 
		//linkTo(methodOn(this.getClass()).RetriveUsers()) ; 
		ControllerLinkBuilder linkTo = linkTo(methodOn(this.getClass()).RetriveUsers()) ;
		resource.add(linkTo.withRel("all_user_link")); 
		return resource ; 
	}
	
	@PostMapping("/users")
	public ResponseEntity<Object> setUser(@Valid @RequestBody User newUser)
	{ 
		LOGGER.info("inside setUser Controller");  
		User SavedUser = service.Save(newUser) ; 
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(SavedUser.getId()).toUri() ; 
		return ResponseEntity.created(location).build() ; 
	}
	@DeleteMapping("/users/{id}")
	public ResponseEntity<Object> deleteUser(@PathVariable String id){
		User user = new User() ; 
		user = service.Deluser(id); 
		LOGGER.info("inside deleteUser controller");  
		if ( user == null)
		{ 
			//throw new UserNotFoundException("ID not found : "+ id) ; 
			//URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(user.getId()).toUri() ; 
			return ResponseEntity.noContent().build() ;
		}
		//URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(user.getId()).toUri() ; 
		return (ResponseEntity<Object>) ResponseEntity.accepted().header("Deleted",  id) ;
		
		
	}

}
