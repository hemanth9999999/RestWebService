package com.hemanth.rest.webservices.restfulwebsevices.helloWorld.EnvConfig;

import java.io.IOException;

import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.hadoop.hbase.HbaseTemplate;



@Configuration
public class ServicesConfig {
	
	  @Autowired
	  private Environment env;

	  private HbaseTemplate hbaseTemplate;
	  
	  @Bean({ "hbaseTemplate" })
	  public HbaseTemplate getHbaseTemplate() {
	    org.apache.hadoop.conf.Configuration conf = HBaseConfiguration.create();
	    conf.set("hbase.zookeeper.quorum", env.getProperty("hbase.zookeeper.quorum", ""));
	    conf.set("hbase.zookeeper.property.clientPort",
	        env.getProperty("hbase.zookeeper.property.clientPort", ""));
	    hbaseTemplate = new HbaseTemplate(conf);
	    return hbaseTemplate;
	  }
	  
	  @Bean(name = "table" 	)
	  public Table getHtable(){ 
		  org.apache.hadoop.conf.Configuration conf = HBaseConfiguration.create();
		    conf.set("hbase.zookeeper.quorum", env.getProperty("hbase.zookeeper.quorum", ""));
		    conf.set("hbase.zookeeper.property.clientPort",
		        env.getProperty("hbase.zookeeper.property.clientPort", ""));
		    Connection connection = null;
			try {
				connection = ConnectionFactory.createConnection(conf);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Trouble establishing the connection\n" + e );
			}
			Table table = null;
			try {
				table = connection.getTable(TableName.valueOf(env.getProperty("user.hbase.table.path")));
			} catch (Exception e) {
				System.out.println("Exception while creating bean of type Table ") ; 
				e.printStackTrace();
			}
		
		    return table ; 
	  }

}