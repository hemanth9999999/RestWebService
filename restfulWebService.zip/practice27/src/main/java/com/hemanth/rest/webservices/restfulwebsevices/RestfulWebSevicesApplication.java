package com.hemanth.rest.webservices.restfulwebsevices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = { "com.hemanth.rest.webservices.restfulwebsevices","com.hemanth.rest.webservices.restfulwebsevices.helloWorld.EnvConfig","com.hemanth.rest.webservices.restfulwebsevices.helloWorld"   })
public class RestfulWebSevicesApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(RestfulWebSevicesApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		// TODO Auto-generated method stub
		return builder.sources(RestfulWebSevicesApplication.class);
	}
	
   
}
