package com.hemanth.rest.webservices.restfulwebsevices.helloWorld;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.hadoop.hbase.HbaseTemplate;
import org.springframework.stereotype.Component;
import java.text.SimpleDateFormat;  
import com.mapr.org.apache.hadoop.hbase.util.Bytes;
import org.springframework.data.hadoop.hbase.RowMapper;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.springframework.data.hadoop.hbase.TableCallback;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.HTableInterface;


@Component
public class UserDaoService  {
	
	
	  @Autowired
      @Qualifier("hbaseTemplate")
	  private  HbaseTemplate hbaseTemplate;
	  
	  @Value("${hbase.zookeeper.quorum}")
	  private  String hbaseQuorum;

	  @Value("${user.hbase.table.path}")
	  private   String UserTablePath;

	  @Value("${user.hbase.column.family}")
	  private  String UsersColumnFamily;
	  
	  
	  @Autowired
      @Qualifier("table")
	  private  Table table;

	  Integer   maxRowNum  ;
	  

	public Table getTable() {
		return table;
	}

	public void setTable(Table table) {
		this.table = table;
	}

	public HbaseTemplate getHbaseTemplate() {
		return hbaseTemplate;
	}

	public void setHbaseTemplate(HbaseTemplate hbaseTemplate) {
		this.hbaseTemplate = hbaseTemplate;
	}

	public String getHbaseQuorum() {
		return hbaseQuorum;
	}

	public void setHbaseQuorum(String hbaseQuorum) {
		this.hbaseQuorum = hbaseQuorum;
	}

	public String getUserTablePath() {
		return UserTablePath;
	}

	public void setUserTablePath(String userTablePath) {
		UserTablePath = userTablePath;
	}

	public String getUsersColumnFamily() {
		return UsersColumnFamily;
	}

	public void setUsersColumnFamily(String usersColumnFamily) {
		UsersColumnFamily = usersColumnFamily;
	}

	public byte[] getId() {
		return Id;
	}

	public void setId(byte[] id) {
		Id = id;
	}

	public byte[] getName() {
		return name;
	}

	public void setName(byte[] name) {
		this.name = name;
	}

	public byte[] getBday() {
		return Bday;
	}

	public void setBday(byte[] bday) {
		Bday = bday;
	}

	public Charset getCh() {
		return ch;
	}

	private final Charset ch = Charset.forName("UTF-8");

	  public UserDaoService(HbaseTemplate hbaseTemplate) {
	    this.hbaseTemplate = hbaseTemplate;
	  }
	
	    

	    public  byte[] CF_INFO = "USER_FAMILY".getBytes(ch);
	    private byte[] Id = "Id".getBytes();
	    private byte[] name = "name".getBytes();
	    private byte[] Bday = "Bday".getBytes();

	    
	public Date ConvertStringDate (String SDate1) throws Exception{
	
		Date date1=new SimpleDateFormat("yyyy-MM-dd").parse(SDate1);
		return date1 ; 
	}
	public static float toFloat(byte[] bytes) {
	    return ByteBuffer.wrap(bytes).getFloat();
	}
	
	public List < User > findAll() { 
		return hbaseTemplate.find(UserTablePath, "USER_FAMILY", new RowMapper<User>() {
            @Override
            public User mapRow(Result result, int rowNum) throws Exception {
                return new User(Integer.valueOf( Bytes.toString(result.getValue(CF_INFO, Id))),
                        Bytes.toString(result.getValue(CF_INFO, name)),
                        ConvertStringDate(Bytes.toString(result.getValue(CF_INFO, Bday))));
            }
		}); 
	}
	

	public User findUser(String id ){
	 		
		User user = hbaseTemplate.get(UserTablePath, String.valueOf(id), new RowMapper<User>() {
	        @Override
	        public User mapRow(Result result, int rowNum) throws Exception {
                return new User(Integer.valueOf( Bytes.toString(result.getValue(CF_INFO, Id))),
                        Bytes.toString(result.getValue(CF_INFO, name)),
                        ConvertStringDate(Bytes.toString(result.getValue(CF_INFO, Bday))));
            }
		}); 
		
		
		return user;
	
	}
		


	
public User Save ( User user ) { 
	maxRowNum = 0 ; 
	String LastRow1= "" ; 
	
	try {
		Scan scan1 = new Scan();
		ResultScanner scanner1 = table.getScanner(scan1);
		System.out.println("Entering the Loop of scanned records") ;
		for ( Result res : scanner1) {
			LastRow1 = Bytes.toString(res.getRow()) ; 		 
		}
		scanner1.close();
		System.out.println(LastRow1);
		String[] str = LastRow1.split("_") ; 
		maxRowNum = Integer.parseInt(str[1]) ; 
		maxRowNum = maxRowNum +1 ; 
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		System.out.println("table get the maximum row failed \n" + e);
	}
	return hbaseTemplate.execute(UserTablePath, new TableCallback<User>() {
	            public User doInTable(HTableInterface table) throws Throwable {
	                Put p = new Put(Bytes.toBytes("User_"+ Integer.toString(maxRowNum).toString()));
	                p.add(CF_INFO, Id, Bytes.toBytes(maxRowNum.toString()));
	                p.add(CF_INFO, name, Bytes.toBytes(user.getName()));
	                p.add(CF_INFO, Bday, Bytes.toBytes(user.getBday().toString()));
	                table.put(p);
	                return user; } 
		
	}); 
} 
	
	public Integer getMaxRowNum() {
	return maxRowNum;
}

public void setMaxRowNum(Integer maxRowNum) {
	this.maxRowNum = maxRowNum;
}

public User Deluser ( String id ){

		return null ; 
		
	}

}