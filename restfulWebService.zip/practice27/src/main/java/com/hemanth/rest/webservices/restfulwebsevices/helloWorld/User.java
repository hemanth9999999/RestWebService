package com.hemanth.rest.webservices.restfulwebsevices.helloWorld;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

public class User {
	
	private Integer Id ; 
	
	@Size(min=2,message="The name must have mimimum 3 characters")
	private String name ; 
	
	@Past(message="date must be a past date")
	private Date Bday ;
	
	public Date ConvertStringDate (String SDate1) throws Exception{
		
		Date date1=new SimpleDateFormat("yyyy-MM-dd").parse(SDate1);
		return date1 ; 
	}
	
	public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBday() {
		return  new SimpleDateFormat("yyyy-MM-dd").format(Bday);
		
	}
	public void setBday(Date bday) {
		Bday = bday;
	}
	@Override
	public String toString() {
		return "User [Id=" + Id + ", name=" + name + ", Bday=" + Bday + "]";
	}
	public User(Integer id, String name, Date bday) {
		super();
		Id = id;
		this.name = name;
		Bday = bday;
	}
	public User() {
		super();
	}
	public User(int id2, String name2, String date) throws Exception {
		super();
		Id = id2;
		this.name = name2;
		Bday = ConvertStringDate(date);
	}

	public User(String name, String date) throws Exception  {
		super();
		this.name = name;
		Bday = ConvertStringDate(date);
		Id = 9999999;
	} 
	

}