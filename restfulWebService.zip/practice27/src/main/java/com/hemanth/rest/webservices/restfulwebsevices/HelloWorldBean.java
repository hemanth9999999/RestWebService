package com.hemanth.rest.webservices.restfulwebsevices;

public class HelloWorldBean {
	
	String Message ; 

	@Override
	public String toString() {
		return "HelloWorldBean [Message=" + Message + "]";
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}

	public HelloWorldBean(String Mess) {
		this.Message = Mess ; 
	}
	

}
